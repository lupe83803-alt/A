# Quest Mixed Reality (prototipo Android)

Prototipo Android inspirado en interfaces de realidad mixta. Usa CameraX para mostrar la cámara trasera y dibuja paneles flotantes que se pueden arrastrar con el dedo.

## Compatibilidad prevista
- Android 8.0 o superior (minSdk 26).
- Probado para compilar con Android Gradle Plugin 8.7.3, Kotlin 2.0.21 y SDK 35.
- El teléfono pedirá permiso para usar la cámara.

## Crear el APK

Este paquete contiene el código fuente, no un APK ya compilado. Para generar el APK:

1. Sube esta carpeta a un repositorio de GitHub.
2. Abre la pestaña **Actions**.
3. Ejecuta **Build Android APK** (o espera a que termine el flujo tras subir a `main`/`master`).
4. Abre la ejecución terminada y descarga el artefacto **QuestMixedReality-debug-apk**.
5. Dentro encontrarás `app-debug.apk`, que puedes instalar en tu OPPO A58 4G.

También puedes abrir la carpeta en Android Studio y ejecutar `assembleDebug`.

## Limitaciones del prototipo
- Las ventanas flotan sobre la vista de cámara dentro de la pantalla del teléfono; no están ancladas físicamente al espacio.
- No incluye seguimiento de manos, mapeo de habitación ni oclusión espacial como unas Meta Quest.
- El navegador y reproductor multimedia todavía no están implementados.
