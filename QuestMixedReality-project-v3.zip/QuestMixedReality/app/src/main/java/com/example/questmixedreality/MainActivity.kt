package com.example.questmixedreality

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var root: FrameLayout
    private lateinit var cameraExecutor: ExecutorService
    private var cameraView: PreviewView? = null
    private val requestCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else showMessage("Permite el acceso a la cámara para ver tu habitación.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(12, 14, 20)) }
        setContentView(root)
        setupInterface()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else requestCamera.launch(Manifest.permission.CAMERA)
    }

    private fun setupInterface() {
        val preview = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        cameraView = preview
        root.addView(preview, FrameLayout.LayoutParams(-1, -1))

        val top = TextView(this).apply {
            text = "◉  QUEST MIXED REALITY                                      ●  CÁMARA ACTIVA"
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setPadding(22, 12, 22, 12)
            setBackgroundColor(0xB8202530.toInt())
        }
        root.addView(top, FrameLayout.LayoutParams(-1, dp(48), Gravity.TOP))

        addFloatingWindow("Panel principal", "Bienvenido\n\nTu espacio de realidad mixta está listo.\nArrastra esta ventana para moverla.", 36, 86, 280, 220)
        addFloatingWindow("Accesos rápidos", "Navegador     Galería\n\nMultimedia   Ajustes", 350, 115, 260, 160)

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(10, 8, 10, 8)
            background = rounded(0xDD171B25.toInt(), 28)
        }
        listOf("＋ Ventana", "Ocultar paneles", "Inicio").forEach { label ->
            val button = Button(this).apply {
                text = label; textSize = 11f; isAllCaps = false
                setTextColor(Color.WHITE)
                background = rounded(0xFF343D50.toInt(), 18)
                setOnClickListener {
                    when (label) {
                        "＋ Ventana" -> addFloatingWindow("Nueva ventana", "Panel flotante\n\nPuedes moverme con el dedo.", 90, 100, 250, 175)
                        "Ocultar paneles" -> {
                            for (i in 0 until root.childCount) {
                                val child = root.getChildAt(i)
                                if (child.tag == "floating") child.visibility = if (child.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                            }
                        }
                        else -> showMessage("Quest Mixed Reality · versión 1.0")
                    }
                }
            }
            val lp = LinearLayout.LayoutParams(0, dp(48), 1f); lp.setMargins(dp(4), 0, dp(4), 0)
            dock.addView(button, lp)
        }
        val dockParams = FrameLayout.LayoutParams(dp(390), dp(64), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        dockParams.bottomMargin = dp(18)
        root.addView(dock, dockParams)
    }

    private fun addFloatingWindow(title: String, body: String, x: Int, y: Int, width: Int, height: Int) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xE91B2230.toInt(), 18)
            elevation = dp(12).toFloat()
            tag = "floating"
        }
        val header = TextView(this).apply {
            text = "⠿  $title      ×"
            textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(12), dp(10), dp(12))
            setBackgroundColor(0xFF303B50.toInt())
            setOnTouchListener(DragTouchListener(panel))
            setOnClickListener { panel.visibility = View.GONE }
        }
        val content = TextView(this).apply {
            text = body; textSize = 14f; setTextColor(0xFFE7ECF5.toInt())
            setPadding(dp(16), dp(14), dp(16), dp(14))
            gravity = Gravity.TOP
        }
        panel.addView(header, LinearLayout.LayoutParams(-1, -2))
        panel.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val params = FrameLayout.LayoutParams(dp(width), dp(height), Gravity.TOP or Gravity.START)
        params.leftMargin = dp(x); params.topMargin = dp(y)
        root.addView(panel, params)
    }

    private inner class DragTouchListener(private val target: View) : View.OnTouchListener {
        private var downRawX = 0f; private var downRawY = 0f
        private var startX = 0f; private var startY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val lp = target.layoutParams as FrameLayout.LayoutParams
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY
                    startX = lp.leftMargin.toFloat(); startY = lp.topMargin.toFloat()
                    target.bringToFront(); return true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.leftMargin = (startX + event.rawX - downRawX).toInt().coerceAtLeast(0)
                    lp.topMargin = (startY + event.rawY - downRawY).toInt().coerceAtLeast(dp(48))
                    target.layoutParams = lp; return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
            }
            return false
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(cameraView!!.surfaceProvider) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview)
            } catch (e: Exception) { showMessage("No se pudo iniciar la cámara.") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun showMessage(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), 0x667D8CA8)
    }
    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
}
